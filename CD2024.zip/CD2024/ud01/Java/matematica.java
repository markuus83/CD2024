/**
 * 
 * Creame un programa que:
 *  1. Calcule la raiz cuadrada de 234324
 *  2. Calcule 34 elevado a 17
 */

public class matematica{

    public static void main (String [] args){

        System.out.println("La raiz cuadrada de 234324 tiene como solución: " + Math.sqrt(234324));
        System.out.println("\nLa operación 34 elevado a 17 tiene como resultado: " + Math.pow(34,17));
    }
}