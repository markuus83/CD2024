/* Programa: Hola mundo */
#include <stdio.h>

void main()
{
    printf( "Son un developer top!! \n" );
    printf( "Hello kitty miau!!");
}
